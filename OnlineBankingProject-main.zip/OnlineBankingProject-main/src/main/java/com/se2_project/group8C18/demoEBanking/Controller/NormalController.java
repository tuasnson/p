package com.se2_project.group8C18.demoEBanking.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class NormalController {
	// Ko muon viet dau :v
}
