package com.se2_project.group8C18.demoEBanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
